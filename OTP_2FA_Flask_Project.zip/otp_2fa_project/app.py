from flask import Flask, render_template, request
import sqlite3
import pyotp
import qrcode
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)

def get_db():
    return sqlite3.connect("users.db")

def init_db():
    con = get_db()
    cur = con.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        password TEXT,
        secret TEXT
    )
    """)
    con.commit()

init_db()

@app.route('/')
def home():
    return render_template("register.html")

@app.route('/register', methods=['POST'])
def register():
    username = request.form['username']
    password = generate_password_hash(request.form['password'])

    secret = pyotp.random_base32()

    con = get_db()
    cur = con.cursor()
    cur.execute("INSERT INTO users(username,password,secret) VALUES (?,?,?)",
                (username, password, secret))
    con.commit()

    totp = pyotp.TOTP(secret)
    uri = totp.provisioning_uri(name=username, issuer_name="OTP-2FA-App")

    img = qrcode.make(uri)
    img.save("static/qrcode.png")

    return render_template("login.html")

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    con = get_db()
    cur = con.cursor()
    user = cur.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()

    if user and check_password_hash(user[2], password):
        return render_template("otp.html", username=username)

    return "Invalid Username or Password"

@app.route('/verify', methods=['POST'])
def verify():
    username = request.form['username']
    otp = request.form['otp']

    con = get_db()
    cur = con.cursor()
    user = cur.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()

    totp = pyotp.TOTP(user[3])

    if totp.verify(otp):
        return render_template("success.html")

    return "Invalid OTP"

if __name__ == "__main__":
    app.run(debug=True)
